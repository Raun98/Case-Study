package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity // This tells Hibernate to make a table out of this class
public class Subscriber  {
  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  private int id;
  private String subscriber_name;
  
  private String date_sub;
  private String date_returned;
  private int book_id;


  
  
  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }
  public int getBookId() {
	return book_id;
  }

  public void setBookId(int id) {
	    this.book_id = id;
  }

  public String getName() {
    return subscriber_name;
  }

  public void setName(String name) {
    this.subscriber_name = name;
  }

  public String getDateSub() {
    return date_sub;
  }

  public void setDateSub(String date) {
    this.date_sub = date;
  }
  
  public String getDateReturned() {
	    return date_returned;
  }

  public void setDateReturned(String date) {
	    this.date_sub = date;
  }
  

}